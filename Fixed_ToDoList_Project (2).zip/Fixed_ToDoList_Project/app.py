from flask import Flask, render_template_string, request, redirect, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Needed for flashing messages

# In-memory storage for tasks
tasks = []
task_id_counter = 1

# HTML Template (no JavaScript, full server-side validation)
template = """
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>To-Do List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        .flash {
            background-color: #ffdddd;
            border: 1px solid #ff5c5c;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            color: #a70000;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"] {
            padding: 10px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            padding: 10px 15px;
            background-color: #4CAF50;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            background-color: white;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        a {
            margin-left: 10px;
            text-decoration: none;
            color: #007BFF;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>📝 To-Do List</h1>

    {% for message in get_flashed_messages() %}
        <div class="flash">{{ message }}</div>
    {% endfor %}

    <form action="/add" method="post">
        <input type="text" name="title" placeholder="Enter your task here...">
        <input type="submit" value="Add Task">
    </form>

    <ul>
        {% for task in tasks %}
            <li>
                {% if task.completed %}
                    <strike>{{ task.title }}</strike>
                {% else %}
                    {{ task.title }}
                {% endif %}
                <a href="/complete/{{ task.id }}">✅ Complete</a>
                <a href="/delete/{{ task.id }}">🗑️ Delete</a>
            </li>
        {% endfor %}
    </ul>
</body>
</html>
"""

# Task Model
class Task:
    def __init__(self, id, title):
        self.id = id
        self.title = title
        self.completed = False

# Home Route
@app.route('/')
def index():
    return render_template_string(template, tasks=tasks)

# Add Task Route
@app.route('/add', methods=['POST'])
def add_task():
    global task_id_counter
    title = request.form.get('title', '').strip()
    if not title:
        flash("Please enter a task before submitting!")
        print("[ERROR] Empty task submitted.")
        return redirect('/')
    if len(title) > 100:
        flash("Task is too long! Maximum 100 characters allowed.")
        print("[ERROR] Task too long submitted.")
        return redirect('/')
    new_task = Task(task_id_counter, title)
    tasks.append(new_task)
    print(f"[INFO] Task Added: {title}")
    task_id_counter += 1
    return redirect('/')

# Complete Task Route
@app.route('/complete/<int:id>')
def complete_task(id):
    found = False
    for task in tasks:
        if task.id == id:
            task.completed = True
            print(f"[INFO] Task Completed: {task.title}")
            found = True
            break
    if not found:
        print(f"[ERROR] Attempted to complete non-existent task with ID {id}.")
    return redirect('/')

# Delete Task Route
@app.route('/delete/<int:id>')
def delete_task(id):
    global tasks
    found = False
    for task in tasks:
        if task.id == id:
            print(f"[INFO] Task Deleted: {task.title}")
            found = True
            break
    if not found:
        print(f"[ERROR] Attempted to delete non-existent task with ID {id}.")
    tasks = [task for task in tasks if task.id != id]
    return redirect('/')

# Error Handling
@app.errorhandler(404)
def page_not_found(e):
    print("[ERROR] 404 Page Not Found")
    return "<h1>404 - Page Not Found</h1>", 404

@app.errorhandler(405)
def method_not_allowed(e):
    print("[ERROR] 405 Method Not Allowed")
    return "<h1>405 - Method Not Allowed</h1>", 405

if __name__ == '__main__':
    app.run(debug=True)
